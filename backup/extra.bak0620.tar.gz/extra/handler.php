<?PHP

require_once("lib/Toro/toro.php");

// ==========================================
// init global db handler

require_once("lib/ezSQL/shared/ez_sql_core.php");
require_once("lib/ezSQL/mysql/ez_sql_mysql.php");

$mydb = new ezSQL_mysql('root', 'root', 'db_test_extra', 'localhost');
//$mydb->get_var("SELECT count(*) FROM test_wp01_users");


// ===========================================




class HelloHandler {
    function get() {
      echo "Hello, world";
    }
}

class DefaultHandler {

    function __construct() {
        //ToroHook::add("before_handler", function() { echo "Before  <>  ";/* echo $_SERVER['REQUEST_URI'];*/ echo "test aaa"; });
        //ToroHook::add("after_handler", function() { echo "After  <>  "; echo $_SERVER['REQUEST_URI']; });
    }

   function get()  {
      //echo  " this is default";
      include("wp-index.php");
    }

}

class ApiHandler {

     function get() {
       echo " this is api get ";

     }
     function get_xhr() {

         $action = $_GET["action"];
         $id = $_GET["postid"];
         
         //echo $action.$id;
        
         $json = '{"a":1,"b":2,"c":3,"d":4,"e":5}'; 
         echo $json; 
  
  
       // echo "aabbccd";


     }

}


class ApiPicasaHandler {

    function get() {
           echo "aabbccdd"; 
           // test code here
           $albumsArray = '[{"al_id":"6157842700476096001","al_num":1,"al_title":"2015-06-07","al_feature":"http://lh3.googleusercontent.com/-kSX_nHBm5ik/VXUNT3icHgE/AAAAAAAAAKk/xJ62xX9p0CY/2015060707.jpg"},{"al_id":"6157827782655382369","al_num":2,"al_title":"2015-06-07","al_feature":"http://lh3.googleusercontent.com/-boPc1GStSiI/VXT_viU0k2E/AAAAAAAAAJs/zlb5QlfFwgo/2015060706.jpg"}]';
		
		;
           /*
           $albumsArray =
		[
		{"al_id":"6157842700476096001","al_num":1,"al_title":"2015-06-07","al_feature":"http://lh3.googleusercontent.com/-kSX_nHBm5ik/VXUNT3icHgE/AAAAAAAAAKk/xJ62xX9p0CY/2015060707.jpg"},
		{"al_id":"6157827782655382369","al_num":2,"al_title":"2015-06-07","al_feature":"http://lh3.googleusercontent.com/-boPc1GStSiI/VXT_viU0k2E/AAAAAAAAAJs/zlb5QlfFwgo/2015060706.jpg"},
		{"al_id":"6157826317270067777","al_num":1,"al_title":"2015-06-07","al_feature":"http://lh3.googleusercontent.com/-NLWKiXBxIR8/VXT-aPVvKkE/AAAAAAAAAI0/TngevfBJk8I/2015060705.jpg"},
		{"al_id":"6157825214333559265","al_num":2,"al_title":"ceshi","al_feature":"http://lh3.googleusercontent.com/-7vF3Hh2Jgh4/VXT9aClLoeE/AAAAAAAAAIY/F0LashBj5fY/Ceshi.jpg"},
		{"al_id":"6157612275878765809","al_num":1,"al_title":"2015-06-07","al_feature":"http://lh3.googleusercontent.com/-lvqkwwHA1i8/VXQ7vZBWpPE/AAAAAAAAAHA/AS22uXTFQP4/2015060703.jpg"},
		{"al_id":"6154490222759004897","al_num":2,"al_title":"test01","al_feature":"http://lh3.googleusercontent.com/-hrigwhMCnho/VWkkP-0qSuE/AAAAAAAAAD0/eyIb4z1o2Tc/Test01.jpg"},
		{"al_id":"5994860578277672017","al_num":0,"al_title":"Profile Photos","al_feature":"http://lh3.googleusercontent.com/-S81Et3tWIYw/UzIF7w47xFE/AAAAAAAAACY/87zsqKY65L0/ProfilePhotos.jpg"}
		];

            */
		global $mydb;
		//$albumsArray = $_POST['albums'];
                
	//	$albums = json_decode($albumsArray, true);
	//	$counts = count($albums);
                //echo $counts+'\n' ;//  echo $albumsArray; echo $albums;
                echo "================        ";
                //echo $albums[0]['al_id'];   echo $albums[1]['al_title']; echo "======="; echo $albums[0]['al_num'];
            //   $str = 'INSERT INTO album ( al_id, al_num, al_title, al_feature) VALUES ("'. $al_id .'",' .$al_num . ',"' . $al_title . '","' . $al_feature . '"))';
               // echo $str  ;

	 /*	
                for( $i=0; $i<$counts; $i++) 
		{
		    $al_id =(string)$albums[$i]['al_id'];
		    $al_num = (string)$albums[$i]['al_num'];
		    $al_title = (string)$albums[$i]['al_title'];
		    $al_feature = (string)$albums[$i]['al_feature'];
                    echo "now in foooooooooor";
                    //echo $al_id ; echo "nwo is al_num : ++++++++++"; echo  $al_num ; // $al_title + " ****";
		    //$str = 'INSERT INTO album ( al_id, al_num, al_title, al_feature) VALUES ("'+ $al_id +'",' +$al_num+ ',"' + $al_title + '","' + $al_feature + '"))';
                    $str = 'INSERT INTO albums ( al_id, al_num, al_title, al_feature) VALUES ("'. $al_id .'",' .$al_num . ',"' . $al_title . '","' . $al_feature . '")';
               
                    //echo "now is combine str: ****"; echo $str  ;
		    //echo $mydb->query($str);
		} 
          */
                $albums = json_decode($albumsArray, true);
		$rows = count($albums);
		for( $i=0; $i<$rows; $i++) 
		{
                    echo "now begin foo";
		    $al_id =$albums[$i]['al_id'];
		    $al_num = $albums[$i]['al_num'];
		    $al_title = $albums[$i]['al_title'];
		    $al_feature = $albums[$i]['al_feature'];

		    $str = 'INSERT INTO albums ( al_id, al_num, al_title, al_feature) VALUES ("'. $al_id . '",'.$al_num . ',"' . $al_title . '","' . $al_feature . '")';
                    echo $str;
		    $mydb->query($str);
		}
                


    }
    
    function post_xhr() {
        //$url_save_album = '/^[/]api[/]picasa[/]save_album(.*)$/';
        //if( preg_match( $url_save_album , $_SERVER['REQUEST_URI']))
        {
              echo $_POST['albums'];
             //$json = '{"a":1,"b":2,"c":3,"d":4,"e":5}'; 
             // echo $json; 

                global $mydb;
		$albumsArray = $_POST['albums'];
		$albums = json_decode($albumsArray, true);
		$rows = count($albums);
		for( $i=0; $i<$rows; $i++) 
		{
		    $al_id =$albums[$i]['al_id'];
		    $al_num = $albums[$i]['al_num'];
		    $al_title = $albums[$i]['al_title'];
		    $al_feature = $albums[$i]['al_feature'];

		    $str = 'INSERT INTO albums ( al_id, al_num, al_title, al_feature) VALUES ("'. $al_id . '",' . $al_num . ',"' . $al_title . '","' . $al_feature . '")';
		    $mydb->query($str);
		}  

        }     

    }
}


?>
