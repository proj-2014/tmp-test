



jQuery(document).ready(function(){
    //alert(" ready ok ");
   jQuery.aop.before( {target: window, method: 'vpml_showalbum'}, 
        function() { 
            //alert('About to execute vpml_showalbum'); 
            save_albums("www");
        }
   );


   
    
});

function save_albums(jour) {

	var jurl = "http://picasaweb.google.com/data/feed/api/user/112389034152258078738?kind=album&access=public&alt=json";

	var albums = [];
        
	jQuery.getJSON(jurl, function(data){
		  if(data.feed.entry) {
		      var entry = data.feed.entry;
		      
		      for (var item=0; item<entry.length; item++) {
			  element = entry[item];
			  al_id = element["gphoto$id"]["$t"];
			  al_num = element["gphoto$numphotos"]["$t"];
			  al_title = element["title"]["$t"];
			  al_feature = element["media$group"]["media$content"][0]["url"];
			  
			  var str = '{"al_id":"'+ al_id + '", "al_num":' + al_num + ',"al_title":"' + al_title +'","al_feature":"'+ al_feature +'"}';
			  //alert(item + ":" + str);
	   
			  var obj = eval('(' + str + ')');
			  //var obj = JSON.parse(str);
			  albums.push(obj);        
		      }
		      //alert(albums[0].al_id);
		  } 
              
                  if( albums.length >0 ) {

		      var jsonAlbums = JSON.stringify(albums);
		      var ajax_url = "/api/picasa/save_album" ;
                      alert("to url is: "+ ajax_url);
	              //alert(jsonAlbums);
	    
		      jQuery.ajax({   
			    url:ajax_url, 
			    type:'POST',   
			    data:{"albums":jsonAlbums},  
                            dataType:"json",
			    //contentType:"application/json; charset=utf-8",
			    success:function(data){   
				 //var result = data.restlt;   
				 //if(results.trim() == 'y') 
				 //    alert("save success");
                                 //alert(JSON.stringify(data));
                                 alert(JSON.stringify(data));
			    }  
		      });  
		  }       


	}).fail(function() {
	     alert('User not found! Please try again!');
	});


}



/*
function save_albums(jurl){

jurl = "http://picasaweb.google.com/data/feed/api/user/112389034152258078738?kind=album&access=public&alt=json";

alert("jurl");

var albums = [];

jQuery.getJSON(jurl, function(data) {
            //if(data.feed.entry)
            //   alert("maybe ok");
            //alert(JSON.stringify(data));
        //});
            
            if (data.feed.entry) {
                var entry = data.feed.entry;
                alert(JSON.stringify(entry));
                //for (var element in entry ){
                jQuery.each(data.feed.entry, function(i, element) {
                    alert(JSON.stringify(element));
                    al_id = element["gphoto$id"]["$t"];
                    al_num = element["gphoto$numphotos"]["$t"];
                    al_title = element[title]["$t"];
                    al_feature = element["media$group"]["media$content"][0];
                
                    var str = '{"al_id":'+ al_id + ', "al_num":' + al_num + ',"al_title":' + al_title +',"al_feature":'+ al_feature +'}';
                    alert(str);
                    var obj = eval('(' + str + ')');
                    albums.push(obj);                
                });
                alert(albms[0].al_id);
             }            
           }).fail(function() {
              alert('User not found! Please try again!');
            });

}
*/
