



//document ready
$(document).ready(function(){
    alert(" ready ok ");
    

});
